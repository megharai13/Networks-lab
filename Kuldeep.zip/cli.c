#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<unistd.h>
#include<netdb.h>


void error(char *msg){
   perror(msg);
   exit(1);
 }
 
 int main(int argc,char *argv[]){
        int n;
        int list[n];
 
        if(argc<3) error("port or address not found");
        
        int portno = atoi(argv[2]);
        
        struct hostent server = gethostbyname(argv[1]);
        
        int sockfd = socket(AF_INET,SOCK_STREAM,0);
        
        if(sockfd<0) error("Opening socket failed");
        
        struct sockaddr_in serv_addr;
       
        bzero((char *)&serv_addr,sizeof(serv_addr)); 
        serv_addr.sin_family = AF_INET;
        bcopy(server->h_addr,(char *) &serv_addr.sin_addr.s_addr,server->h_length);
        serv_addr.sin_port = htons(portno);
        
        if(connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0) error("connection failed");
        
        printf("Enter size of the list : ");
        scanf("%d",&n);
        int r=write(sockfd,&n,sizeof(n));
        if(r<0) error("error in writing");
        printf("Enter the elements in the list : \n");
        for(int i=0; i<n; i++){
              scanf("%d",&list[i]);
              }
        r = write(sockfd,list,
              
        
 
 }
