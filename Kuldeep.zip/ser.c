#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

void error(char *msg){
    perror(msg);
    exit(1);
}

int main(int argc,char *argv[]){
    int n;
    int *list;
    if(argc<2){
            error("port number not found");
        }
        
    int portno = atoi(argv[1]);
    int sockfd = socket(AF_INET,SOCK_STREAM,0);
    
    if(sockfd<0) error("Opening socket fault");
        
    struct sockaddr_in ser_addr,cli_addr;
    bzero((char*)&ser_addr,sizeof(ser_addr));
    
    ser_addr.sin_family = AF_INET;
    ser_addr.sin_addr.s_addr = INADDR_ANY;
    ser_addr.sin_port = htons(portno);
    
    
    if(bind(sockfd,(struct sockaddr *)&ser_addr,sizeof(ser_addr))<0) error("Binding error");
    
    listen(sockfd,3);
    
    socklen_t clilen = sizeof(cli_addr);
    
    int newsockfd = connect(sockfd,(struct sockaddr *)&cli_addr,&clilen);
    
    if(newsockfd<0) error("connect failed");
    
    int r = read(newsockfd,&n,sizeof(n));
    if(r<0) error("Error in reading");
    
    printf("List of the size %d\n",n);
    
    r = read(newsockfd,list,sizeof(list));
    
    printf("Element of the list\n");
    for(int i=0; i<n; i++){
        printf("%d ",list[i]);
     }
       
     printf("\n");
        
        
    
}
